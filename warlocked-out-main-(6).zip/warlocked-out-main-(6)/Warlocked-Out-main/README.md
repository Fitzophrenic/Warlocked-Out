# Warlocked-Out
A 2.5D Metroidvania game with a unique gesture-based spellcasting system
